angular.module('handdrawnRectangle', ['servoy']).directive('handdrawnRectangle', function($timeout, $svyProperties) {
		return {
			restrict: 'E',//$NON-NLS-1$
			scope: {
				model: '=svyModel',//$NON-NLS-1$
				svyServoyapi: '=svyServoyapi'//$NON-NLS-1$
			},
			controller: function($scope, $element, $attrs, $window) {

				
				
				// cache the canvas
				var paper;
				// piant first time
				paint();
				

				
				//create observer to redraw on resize, when in developer
				if ($scope.svyServoyapi.isInDesigner()) {		
				    
					// Listen to changes on the elements in the page that affect layout 
					var observer = new MutationObserver(checkSize);
				    observer.observe($element.parent()[0], { 
				      attributes: true,
				      childList: false,
				      characterData: false,
				      subtree: false 
				    });
					
				}

				//check if resized, if true run resize
				function checkSize() {
					var element =  $element.parent();
					var product = element.width() + element.height();
					if ($scope.height !== product) {
						$scope.height = product;
						resize();
					}
				}
				
				$scope.$watch('model.textLocation', function(newValue, oldValue) {
					resize();
				}, true);
				
				$scope.$watch('model.displayText', function(newValue, oldValue) {
					resize();
				}, true);
				

				$scope.$watch('model.size.width', function(newValue, oldValue) {
						resize();
					}, true);
				
				$scope.$watch('model.size.height', function(newValue, oldValue) {
					resize();
				}, true);
				
				
				$scope.$watch('model.fontType', function(newValue, oldValue) {
					resize();
				}, true);
				
				$scope.$watch('model.textHorizontalAlignment', function(newValue, oldValue) {
					resize();
				}, true);
				
				
				$scope.$watch('model.textVerticalAlignment', function(newValue, oldValue) {
					resize();
				}, true);

				function resize() {
					// resize the paper if already drawn
					if (paper) {
						paper.clear();
						paint();
					}
				}

				function paint() {
					var element = $element.find('.svy-rectangle')[0];
					var jqelement = $element.parent();

					if ($element.parent().hasClass('.svy-wrapper')) { 
						//responsive
						var jqelement = $element.parent();
						var hdWidth = $scope.model.size.width;
						var hdHeight = $scope.model.hoogte;
						var myNewDiv = "<div id='omg'></div>";
						jqelement.append(myNewDiv);
						myNewDiv = $( "#omg" );
						myNewDiv.width(hdWidth);
						myNewDiv.heigth(hdHeight);
						myNewDiv.css("display", "inline-block");
						
						var paperRect = Raphael(jqelement, hdWidth+ 'px', hdHeight+ 'px');
						//paperRect.setSize(hdWidth + 'px', hdHeight + 'px');
					} else {
						//anchored
						var hdWidth = jqelement.width();
						var hdHeight = jqelement.height(); 
						var paperRect = Raphael(element, '100%', hdHeight + 'px');
					}
					
					
					var margin = 2;
					
					
					
					//paperRect.setViewBox(0, 0, hdWidth+ 'px', hdHeight+ 'px', true);
					
					paperRect.drawnRect(
						margin,
						margin,
						hdWidth-2*margin,
						hdHeight-2*margin,
						1.5
					).attr({ stroke: "#000", "stroke-width": margin });
					paperRect.drawnLine(2, 2, hdWidth-3, hdHeight-3, 2).attr({ stroke: "#000", "stroke-width": 2 });
					paperRect.drawnLine(hdWidth -3, 2, 2, hdHeight-2,2).attr({ stroke: "#000", "stroke-width": 2 });
					
					

					
					switch($scope.model.textHorizontalAlignment + "|" + $scope.model.textVerticalAlignment) {
					    case "Left|Top":
					    	paperRect.text($scope.model.textLocation.x + margin *2,$scope.model.textLocation.y + parseInt($scope.model.fontType.fontSize)/2+ margin *2, $scope.model.displayText  ).attr({'text-anchor': 'start', 'font-family': $scope.model.fontType.fontFamily, 'font-size': $scope.model.fontType.fontSize })
					        break;
					    case "Center|Top":
					    	paperRect.text($scope.model.textLocation.x + hdWidth/2,$scope.model.textLocation.y + parseInt($scope.model.fontType.fontSize)/2+ margin *2, $scope.model.displayText  ).attr({'text-anchor': 'middle', 'font-family': $scope.model.fontType.fontFamily, 'font-size': $scope.model.fontType.fontSize })
					        break;
					    case "Right|Top":
					    	paperRect.text($scope.model.textLocation.x + hdWidth - margin *2,$scope.model.textLocation.y + parseInt($scope.model.fontType.fontSize)/2+ margin *2, $scope.model.displayText  ).attr({'text-anchor': 'end', 'font-family': $scope.model.fontType.fontFamily, 'font-size': $scope.model.fontType.fontSize })
					        break;
					    case "Left|Middle":
					    	paperRect.text($scope.model.textLocation.x,$scope.model.textLocation.y + hdHeight/2 , $scope.model.displayText  ).attr({'text-anchor': 'start', 'font-family': $scope.model.fontType.fontFamily, 'font-size': $scope.model.fontType.fontSize })
					    	break;
				        case "Center|Middle":
				        	paperRect.text($scope.model.textLocation.x + hdWidth/2 ,$scope.model.textLocation.y + hdHeight/2 , $scope.model.displayText  ).attr({'text-anchor': 'middle', 'font-family': $scope.model.fontType.fontFamily, 'font-size': $scope.model.fontType.fontSize })
				        	break;
				        case "Right|Middle":
				        	paperRect.text($scope.model.textLocation.x + hdWidth - margin *2,$scope.model.textLocation.y + hdHeight/2 , $scope.model.displayText  ).attr({'text-anchor': 'end', 'font-family': $scope.model.fontType.fontFamily, 'font-size': $scope.model.fontType.fontSize })
				        	break;
					    case "Left|Bottom":
					    	paperRect.text($scope.model.textLocation.x,$scope.model.textLocation.y + hdHeight - parseInt($scope.model.fontType.fontSize)/2 , $scope.model.displayText  ).attr({'text-anchor': 'start', 'font-family': $scope.model.fontType.fontFamily, 'font-size': $scope.model.fontType.fontSize })
					    	break;
					    case "Center|Bottom":
					    	paperRect.text($scope.model.textLocation.x + hdWidth/2,$scope.model.textLocation.y + hdHeight - parseInt($scope.model.fontType.fontSize)/2 , $scope.model.displayText  ).attr({'text-anchor': 'middle', 'font-family': $scope.model.fontType.fontFamily, 'font-size': $scope.model.fontType.fontSize })
					    	break;
					    case "Right|Bottom":
					    	paperRect.text($scope.model.textLocation.x + hdWidth - margin *2,$scope.model.textLocation.y + hdHeight - parseInt($scope.model.fontType.fontSize)/2, $scope.model.displayText  ).attr({'text-anchor': 'end', 'font-family': $scope.model.fontType.fontFamily, 'font-size': $scope.model.fontType.fontSize })
				        break;
					}
					
					
					paper = paperRect;
				}

				

			},
			templateUrl: 'handdrawn/rectangle/rectangle.html'
		};
	})