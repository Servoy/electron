angular.module('electron',['servoy'])
.factory("electron",['$services', '$q', function($services, $q) 
{
	var scope = $services.getServiceScope('electron');
	var ipc = ipcRenderer;
	
	
	var textFile = null;
	
	return {
		electron: function(text) {
			alert("helloworld: " + scope.model.text + text);
		},
		saveTextFile: function(text) {
			var data = new Blob([text], {type: 'text/plain'});
			var fileNameToSaveAs = "myNewFile.txt";
			var downloadLink = document.createElement("a");
			downloadLink.download = fileNameToSaveAs;
			window.URL = window.URL || window.webkitURL;
			downloadLink.style.display = "none";
			downloadLink.href = window.URL.createObjectURL(data);
			document.body.appendChild(downloadLink);
			downloadLink.click();
		},
		saveExcelFile: function(bytes, path){
			var byteArray = new Uint8Array(bytes);
			var downloadLink = document.createElement("a");
			downloadLink.href = window.URL.createObjectURL(new Blob([byteArray], 
				{ type: 'application/octet-stream' }));
			downloadLink.download = "customers.xlsx";
			downloadLink.style.display = "none";
			sendPathIPC(ipc, path);
			document.body.appendChild(downloadLink);
	        downloadLink.click();
		},
		sendMessage: function(text){
			ipc.send('message', text);
		},
		sendToPrinter: function(printer_name, text) {
			var printerObject = {"printer":printer_name, "text": text};
			ipc.send('selected-printer', printerObject);
		},
		getPrinterList: function(){
			var deferred = $q.defer();
			ipc.send('get-printers');
			ipc.on('printer-list', function(event, printer_list) {
				 deferred.resolve(printer_list);
			});
			return deferred.promise;
		}
	}
}])
.run(function($rootScope,$services)
{	
	var scope = $services.getServiceScope('electron')
	scope.$watch('model', function(newvalue,oldvalue) {
	// handle state changes
		console.log(newvalue)
}, true);
})

function sendPathIPC(ipc, path){
	if(path !== 'empty') {
		ipc.send('path_specified', path);
	} else {
		ipc.send('path_specified', "empty");
	}
}
